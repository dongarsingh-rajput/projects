const express = require('express');
const Student = require('../routes/student');
const errorMiddleware = require('../middleware/error');
module.exports = function (app) {
  app.use(express.json());
  
  app.use('/api/student', Student);
  app.use(errorMiddleware);
};
