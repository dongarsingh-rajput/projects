const express = require('express');
const router = express.Router();

const { Student, validate } = require('../models/student');
// const validateObjectId = require('../middleware/validateObjectId');
const validateStudent = require('../middleware/validate');
const { check, validationResult } = require('express-validator');
const session = require('express-session');
const HelperUtils = require('./../utils/helpers');
const e = require('express');

router.post('/registration/create', async (req, res) => {

    try {

        // console.log("aaaaa");
        const student = new Student({
            name: req.body.name,
            contact: req.body.contact,
            email: req.body.email,
            address: req.body.address,
            interest: req.body.interest,
            upvotes: req.body.upvotes,
            courseHistory: req.body.courseHistory,
        });
        // console.log(student.name);
        // if (student.contact === "" || student.email != "" || student.address != "" || student.upvotes != "" || student.name != " ") {
        console.log("ccccccc");
        if (!student.name) {
            return res.json({
                flag: false,
                data: "please enter name",

            });
        }
        if (!student.contact) {
            return res.json({
                flag: false,
                data: "please enter contact",

            });
        }
        if (!student.email) {
            return res.json({
                flag: false,
                data: "please enter email",

            });
        }
        if (!student.address) {
            return res.json({
                flag: false,
                data: "please enter address",

            });
        }
        if (!student.upvotes) {
            return res.json({
                flag: false,
                data: "please enter upvotes",

            });
        }
        if (!student.courseHistory) {
            return res.json({
                flag: false,
                data: "please enter course History",

            });
        }
        await student.save()
        res.send(HelperUtils.successObj("Student Added Successfully", student));
        // }
        // else {
        //     console.log("dddddd");
        //     return res.json({
        //         flag: false,
        //         data: "please enter valid data",

        //     });
        // }

    }
    catch (e) {
        return res.json({
            flag: false,
            data: "please enter another contact or email ",

        });
    }


});

router.post('/registration/create', async (req, res) => {

    const student = new Student({
        name: req.body.name,
        contact: req.body.contact,
        email: req.body.email,
        address: req.body.address,
        interest: req.body.interest,
        upvotes: req.body.upvotes,
        courseHistory: req.body.courseHistory,
    });
    await student.save()
    res.send(HelperUtils.successObj("Student Added Successfully", student));

});


// router.post('/registration/create/new', (req, res) => {
//     const name  = req.body.name
//     const email = req.body.email
//     const address   = req.body.address
//     const upvotes  = req.body.name
//     const courseHistory = req.body.email
//     const contact   = req.body.contact
//   })

// router.post(
//     '/registration/create/new',
//     check('name').exists(),
//     check(
//         'name must have field',
//       )
//       .custom((value, { req }) => value === req.body.name)
//       ,
//     check('contact').exists(),
//     check(
//         'contact must have field',
//       )
//       .custom((value, { req }) => value === req.body.contact)
//       ,
//     check('email').exists(),
//     check(
//         'email must have field',
//       )
//       .custom((value, { req }) => value === req.body.email)
//       ,
//     check('address').exists(),
//     check(
//         'address must have field',
//       )
//       .custom((value, { req }) => value === req.body.address)
//       ,
//     check('interest').exists(),
//     check(
//         'interest must have field',
//       )
//       .custom((value, { req }) => value === req.body.interest)
//       ,
//     check('upvotes').exists(),
//     check(
//         'upvotes must have field',
//       )
//       .custom((value, { req }) => value === req.body.upvotes)
//       ,
//     check('courseHistory').exists(),
//     check(
//         'courseHistory must have field',
//       )
//       .custom((value, { req }) => value === req.body.courseHistory)
//   );

router.post('/registration/create/new',
    [check('name', 'name is invalid')
        .exists()
        .isLength({ min: 5 }),
    check('email', 'this mail is not valid')
        .isEmail()
        .normalizeEmail(),
    check('contact', 'contact is invalid')
        .exists(),
    check('Please Enter valid Number')
        .isLength({ min: 10 }),
    check('address', 'address is invalid')
        .exists()
        .isLength({ min: 5 }),
    check('interest', 'interest is invalid')
        .exists()
        .isLength({ min: 5 }),
    check('upvotes', 'upvotes is invalid')
        .exists()
        .isLength({ min: 1 }),
    check('courseHistory', 'courseHistory is invalid')
        .exists()
        .isLength({ min: 5 })

    ], (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            //   return res.status(422).json({ errors: errors.array() });
            const err = errors.array();
            res.send(err);

        } else {
            res.send("success");
        }
    });

// router.post('/registration/create/new',
//     [

//         check('name')
//             .not()
//             .isEmpty()
//             .withMessage('Name is required'),
//         check('email', 'Email is required')
//             .isEmpty(),
//         check('address', 'Address is required')
//             .isEmpty(),
//         check('upvotes', 'Upvotes is required')
//             .isEmpty(),
//         check('courseHistory', 'Course History is required')
//             .isEmpty(),
//         check('contact', 'Contact is requried')
//             .isLength({ min: 1 })
//         // .custom((val, { req, loc, path }) => {
//         //     if (val !== req.body.confirm_password) {
//         //         throw new Error("Passwords don't match");
//         //     } else {
//         //         return value;
//         //     }
//         // }),
//     ], (req, res) => {
//         const errors = validationResult(req)
//         if (!errors.isEmpty()) {
//             return res.status(422).json({ errors: errors.array() })
//         }

//         // const contact   = req.body.address
//         // var errors = validationResult(req).array();
//         // if (errors) {
//         //     // req.session.errors = errors;
//         //     // req.session.success = false;
//         //     res.send(errors);
//         //     // res.redirect('/user');
//         // } else {
//         //     // req.session.success = true;
//         //     // res.redirect('/user');
//         //     res.send(student)
//         // }
//     });

router.get('/list', async (req, res) => {
    const student = await Student.find();
    res.send(HelperUtils.successObj("Student Data retrieved successfully", student));
});

module.exports = router;