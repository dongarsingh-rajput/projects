
function successObj(message, result) {

    return {
        flag: true,
        message: message,
        result: { data: result }
    };
}

module.exports = {
    successObj: successObj,
}