const names = [
    { title: 'Dongarsingh' },
    { title: 'Rajesingh' }
];
function getNames() {
    setTimeout(() => {
        let nameContent = '';
        names.forEach((name, index) => {
            nameContent += `${name.title}` + ` `;
        });
        console.log(nameContent);
    }, 1000);
}
async function createName(name) {
    names.push(name);
}
async function testAsync() {
    await createName({ title: 'Rajput' });
    getNames();
}
testAsync();