const names = [
    { title: 'Dongarsingh' },
    { title: 'Rajesingh' }
];
function getNames() {
    setTimeout(() => {
        let nameContent = '';
        names.forEach((name, index) => {
            nameContent += `${name.title}` + ` `;
        });
        console.log(nameContent);
    }, 1000);
};
function createName(name) {
    return new Promise((resolve, reject) => {
        names.push(name);
        let isError = false;
        if (!isError) {
            resolve();
        } else {
            reject();
        }
    });
}
createName({ title: 'Rajput' })
    .then(getNames());





// handling error with promises:
// const names = [
//     { title: 'Dongarsingh' },
//     { title: 'Rajesingh' }
// ];

function getNames() {
    setTimeout(() => {
        let nameContent = '';
        names.forEach((name, index) => {
            nameContent += `${name.title}` + ` `;
        });
        console.log(nameContent);
    }, 1000);
};
function createName(name) {
    return new Promise((resolve, reject) => {
        names.push(name);
        let isError = true;
        if (!isError) {
            resolve();
        } else {
            reject('Something went wrong');
        }
    });
}
// createName({ title: 'Rajput' })
//     .then(getNames())
//     .catch(error => console.log(error));