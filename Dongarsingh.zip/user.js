
const axios = require('axios');

// create token

const params = new URLSearchParams();
params.append('username', 'guacadmin');
params.append('password', 'EMI-linux09');

// const qs = require('qs');
// const data1 = { username: 'guacadmin', password: 'EMI-linux09' };
const headers = {
  headers: { 'content-type': 'application/x-www-form-urlencoded' },
};
axios.post('https://dcv.electromech.info/api/tokens', params, headers)
  .then(function (response) {

    console.log("Token Generated Successfully", response.data);
    if (response.hasOwnProperty('data')) {
      if (response.data.hasOwnProperty('authToken')) {
        var token = response.data.authToken;
      // }
      // }
      // if (response.data.authToken) {


      const data2 = {
        "username": "user51",
        "password": "users",
        "attributes": {
          "disabled": "",
          "expired": "",
          "access-window-start": "",
          "access-window-end": "",
          "valid-from": "",
          "valid-until": "",
          "timezone": null,
          "guac-full-name": "",
          "guac-organization": "",
          "guac-organizational-role": ""
        }
      };
      const headers2 = {
        headers: { 'content-type': 'application/json' },
      };
      axios.post('https://dcv.electromech.info/api/session/data/mysql/users?token=' + token, data2, headers2)
        .then(function (response) {

          console.log("User created Successfully", response.data);

          // var token = 'C2BFB043BD20BA37E85E22D88CFF69CD96976B26AB9EA5977237FF0C2C4EE7EA';

          const data3 = {
            "parentIdentifier": "ROOT",
            "name": data2.username,
            "protocol": "ssh",
            "parameters": {
              "port": "22",
              "read-only": "",
              "swap-red-blue": "",
              "cursor": "",
              "color-depth": "",
              "clipboard-encoding": "",
              "disable-copy": "",
              "disable-paste": "",
              "dest-port": "",
              "recording-exclude-output": "",
              "recording-exclude-mouse": "",
              "recording-include-keys": "",
              "create-recording-path": "",
              "enable-sftp": "",
              "sftp-port": "",
              "sftp-server-alive-interval": "",
              "enable-audio": "",
              "color-scheme": "",
              "font-size": "",
              "scrollback": "",
              "timezone": null,
              "server-alive-interval": "",
              "backspace": "",
              "terminal-type": "",
              "create-typescript-path": "",
              "hostname": "10.192.173.145",
              "host-key": "",
              "private-key": "",
              "username": data2.username,
              "password": data2.password,
              "passphrase": "",
              "font-name": "",
              "command": "",
              "locale": "",
              "typescript-path": "",
              "typescript-name": "",
              "recording-path": "",
              "recording-name": "",
              "sftp-root-directory": ""
            },
            "attributes": {
              "max-connections": "",
              "max-connections-per-user": "",
              "weight": "",
              "failover-only": "",
              "guacd-port": "",
              "guacd-encryption": "",
              "guacd-hostname": ""
            }
          };

          axios.post('https://dcv.electromech.info/api/session/data/mysql/connections?token=' + token, data3)
            .then(function (response) {
              console.log("SSH Connection created successfullly", response.status, response.statusText);
            })
            .catch(function (error) {
              console.log(error.response.data.message);
            })
        })
        .catch(function (error) {
          console.log(error.response.data.message);
        })
      }
      else{
        throw 'Invalid Token';
      }
    }
    // } else {
    //   // throw 'Invalid Token';
    //   console.log('Invalid Token');
    // }

  })
  .catch(function (error) {
    console.log(error.response.data.message);
  })





// create user


// var token = response.data.authToken;

// const data2 = {
//   "username": "user32",
//   "password": "EMI-linux09",
//   "attributes": {
//     "disabled": "",
//     "expired": "",
//     "access-window-start": "",
//     "access-window-end": "",
//     "valid-from": "",
//     "valid-until": "",
//     "timezone": null,
//     "guac-full-name": "",
//     "guac-organization": "",
//     "guac-organizational-role": ""
//   }
// };
// const headers2 = {
//   headers: { 'content-type': 'application/json' },
// };
// axios.post('https://dcv.electromech.info/api/session/data/mysql/users?token=' + token, data2, headers2).then(function (response) {
//   console.log(response.data);
// })


// create ssh connection 

// var token = 'C2BFB043BD20BA37E85E22D88CFF69CD96976B26AB9EA5977237FF0C2C4EE7EA';

// const data = {
//   "parentIdentifier": "ROOT",
//   "name": "user5",
//   "protocol": "ssh",
//   "parameters": {
//     "port": "22",
//     "read-only": "",
//     "swap-red-blue": "",
//     "cursor": "",
//     "color-depth": "",
//     "clipboard-encoding": "",
//     "disable-copy": "",
//     "disable-paste": "",
//     "dest-port": "",
//     "recording-exclude-output": "",
//     "recording-exclude-mouse": "",
//     "recording-include-keys": "",
//     "create-recording-path": "",
//     "enable-sftp": "",
//     "sftp-port": "",
//     "sftp-server-alive-interval": "",
//     "enable-audio": "",
//     "color-scheme": "",
//     "font-size": "",
//     "scrollback": "",
//     "timezone": null,
//     "server-alive-interval": "",
//     "backspace": "",
//     "terminal-type": "",
//     "create-typescript-path": "",
//     "hostname": "10.192.173.145",
//     "host-key": "",
//     "private-key": "",
//     "username": "user5",
//     "password": "student",
//     "passphrase": "",
//     "font-name": "",
//     "command": "",
//     "locale": "",
//     "typescript-path": "",
//     "typescript-name": "",
//     "recording-path": "",
//     "recording-name": "",
//     "sftp-root-directory": ""
//   },
//   "attributes": {
//     "max-connections": "",
//     "max-connections-per-user": "",
//     "weight": "",
//     "failover-only": "",
//     "guacd-port": "",
//     "guacd-encryption": "",
//     "guacd-hostname": ""
//   }
// };

// axios.post('https://dcv.electromech.info/api/session/data/mysql/connections?token=' + token, data).then(function (response) {
//   console.log(response.data);
// })




























// const axios = require('axios');

// // create token

// const params = new URLSearchParams();
// params.append('username', 'guacadmin');
// params.append('password', 'EMI-linux09');

// // const qs = require('qs');
// // const data1 = { username: 'guacadmin', password: 'EMI-linux09' };
// const headers = {
//   headers: { 'content-type': 'application/x-www-form-urlencoded' },
// };
// axios.post('https://dcv.electromech.info/api/tokens', params, headers)
//   .then(function (response) {

//     console.log("Token Generated Successfully", response.data);
//     if (response.hasOwnProperty('data')) {
//       if (response.data.hasOwnProperty('authToken')) {
//         var token = response.data.authToken;
//       // }
//       // }
//       // if (response.data.authToken) {


//       const data2 = {
//         "username": "user48",
//         "password": "users",
//         "attributes": {
//           "disabled": "",
//           "expired": "",
//           "access-window-start": "",
//           "access-window-end": "",
//           "valid-from": "",
//           "valid-until": "",
//           "timezone": null,
//           "guac-full-name": "",
//           "guac-organization": "",
//           "guac-organizational-role": ""
//         }
//       };
//       const headers2 = {
//         headers: { 'content-type': 'application/json' },
//       };
//       axios.post('https://dcv.electromech.info/api/session/data/mysql/users?token=' + token, data2, headers2)
//         .then(function (response) {

//           console.log("User created Successfully", response.data);

//           // var token = 'C2BFB043BD20BA37E85E22D88CFF69CD96976B26AB9EA5977237FF0C2C4EE7EA';

//           const data3 = {
//             "parentIdentifier": "ROOT",
//             "name": data2.username,
//             "protocol": "ssh",
//             "parameters": {
//               "port": "22",
//               "read-only": "",
//               "swap-red-blue": "",
//               "cursor": "",
//               "color-depth": "",
//               "clipboard-encoding": "",
//               "disable-copy": "",
//               "disable-paste": "",
//               "dest-port": "",
//               "recording-exclude-output": "",
//               "recording-exclude-mouse": "",
//               "recording-include-keys": "",
//               "create-recording-path": "",
//               "enable-sftp": "",
//               "sftp-port": "",
//               "sftp-server-alive-interval": "",
//               "enable-audio": "",
//               "color-scheme": "",
//               "font-size": "",
//               "scrollback": "",
//               "timezone": null,
//               "server-alive-interval": "",
//               "backspace": "",
//               "terminal-type": "",
//               "create-typescript-path": "",
//               "hostname": "10.192.173.145",
//               "host-key": "",
//               "private-key": "",
//               "username": data2.username,
//               "password": data2.password,
//               "passphrase": "",
//               "font-name": "",
//               "command": "",
//               "locale": "",
//               "typescript-path": "",
//               "typescript-name": "",
//               "recording-path": "",
//               "recording-name": "",
//               "sftp-root-directory": ""
//             },
//             "attributes": {
//               "max-connections": "",
//               "max-connections-per-user": "",
//               "weight": "",
//               "failover-only": "",
//               "guacd-port": "",
//               "guacd-encryption": "",
//               "guacd-hostname": ""
//             }
//           };

//           axios.post('https://dcv.electromech.info/api/session/data/mysql/connections?token=' + token, data3)
//             .then(function (response) {
//               console.log("SSH Connection created successfullly", response.status, response.statusText);
//             })
//             .catch(function (error) {
//               console.log(error.response.data.message);
//             })
//         })
//         .catch(function (error) {
//           console.log(error.response.data.message);
//         })
//       }
//       else{
//         // throw 'Invalid Token';
//         console.log('Invalid Token');
//       }
//     }
//     // } else {
//     //   // throw 'Invalid Token';
//     //   console.log('Invalid Token');
//     // }

//   })
//   .catch(function (error) {
//     console.log(error.response.data.message);
//   })





















// create user


// var token = response.data.authToken;

// const data2 = {
//   "username": "user32",
//   "password": "EMI-linux09",
//   "attributes": {
//     "disabled": "",
//     "expired": "",
//     "access-window-start": "",
//     "access-window-end": "",
//     "valid-from": "",
//     "valid-until": "",
//     "timezone": null,
//     "guac-full-name": "",
//     "guac-organization": "",
//     "guac-organizational-role": ""
//   }
// };
// const headers2 = {
//   headers: { 'content-type': 'application/json' },
// };
// axios.post('https://dcv.electromech.info/api/session/data/mysql/users?token=' + token, data2, headers2).then(function (response) {
//   console.log(response.data);
// })


// create ssh connection 

// var token = 'C2BFB043BD20BA37E85E22D88CFF69CD96976B26AB9EA5977237FF0C2C4EE7EA';

// const data = {
//   "parentIdentifier": "ROOT",
//   "name": "user5",
//   "protocol": "ssh",
//   "parameters": {
//     "port": "22",
//     "read-only": "",
//     "swap-red-blue": "",
//     "cursor": "",
//     "color-depth": "",
//     "clipboard-encoding": "",
//     "disable-copy": "",
//     "disable-paste": "",
//     "dest-port": "",
//     "recording-exclude-output": "",
//     "recording-exclude-mouse": "",
//     "recording-include-keys": "",
//     "create-recording-path": "",
//     "enable-sftp": "",
//     "sftp-port": "",
//     "sftp-server-alive-interval": "",
//     "enable-audio": "",
//     "color-scheme": "",
//     "font-size": "",
//     "scrollback": "",
//     "timezone": null,
//     "server-alive-interval": "",
//     "backspace": "",
//     "terminal-type": "",
//     "create-typescript-path": "",
//     "hostname": "10.192.173.145",
//     "host-key": "",
//     "private-key": "",
//     "username": "user5",
//     "password": "student",
//     "passphrase": "",
//     "font-name": "",
//     "command": "",
//     "locale": "",
//     "typescript-path": "",
//     "typescript-name": "",
//     "recording-path": "",
//     "recording-name": "",
//     "sftp-root-directory": ""
//   },
//   "attributes": {
//     "max-connections": "",
//     "max-connections-per-user": "",
//     "weight": "",
//     "failover-only": "",
//     "guacd-port": "",
//     "guacd-encryption": "",
//     "guacd-hostname": ""
//   }
// };

// axios.post('https://dcv.electromech.info/api/session/data/mysql/connections?token=' + token, data).then(function (response) {
//   console.log(response.data);
// })





