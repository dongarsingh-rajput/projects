const promiseA=Promise.resolve('Hello');
const promiseB=111;
const promiseC=new Promise((resolve,reject)=>{
   setTimeout(resolve,2000,'goooo');
});
Promise.all([promiseA,promiseB,promiseC])
.then((values)=>console.log(values));